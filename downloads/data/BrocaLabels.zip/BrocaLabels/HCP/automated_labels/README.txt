This folder contains the results of the automated labeling of Brodmann areas 44 and 45 based on resting-state functional connectivity for 250 individual subjects from the preprocessed ICA-FIX denoised Q3 release of the Human Connectome Project (HCP).

Data are surface-based labels in standard HCP fs_LR_32k grayordinate space, where 1=BA45, 2=BA44, and 0=neither.

Also included are the probability maps of Brodmann areas 44 and 45, created by averaging across the binary manual labels of all 100 (previously manually labeled) and 150 (new) subjects.

Detailed descriptions of the automated labeling pipeline and data processing procedures can be found in:
Jakobsen, E., Liem, F., Klados, M.A., Bayrak, S., Petrides, M., Margulies, D.S. Automated individual-level parcellation of Broca’s region based on functional connectivity. (under review)

Each label file name contains the HCP subject identifier (e.g. 100307). The corresponding datasets can be downloaded through the HCP Database, ConnectomeDB (https://db.humanconnectome.org/). The parcellation pipeline script can be found on Github (https://github.com/NeuroanatomyAndConnectivity/broca/tree/master/PartialCorrelation).
