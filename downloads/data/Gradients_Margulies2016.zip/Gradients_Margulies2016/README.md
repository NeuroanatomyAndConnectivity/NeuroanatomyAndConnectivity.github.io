This directory includes the HCP cifti gradient maps from Margulies et al, PNAS, 2016. Also included are conversion of the the first five gradient maps to fsaverage space (resolutions: fsaverage, fsaverage6, fsaverage5, fsaverage4), and a projection to MNI2mm space for the principal gradient.

The scripts directory contains examples of how the projections were created and would need to be modified based on local directory structure. 
